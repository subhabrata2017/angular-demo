import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-second-page',
  templateUrl: './second-page.component.html',
  styleUrls: ['./second-page.component.css']
})
export class SecondPageComponent implements OnInit {
  
  @Input()
  users: string[] = [];
  
  @Output() 
  newItemEvent = new EventEmitter<string>();
  
  inPutValue: string = "2";
  
  constructor() { }

  ngOnInit() {
    console.log( this.users );
  }
  
  getTextBoxValue() {    
    this.newItemEvent.emit( this.inPutValue );
  }

}
